```
https://cdn.jsdelivr.net/npm/christmas-snow-3d/build/snow3d.js

<script type="text/javascript" async src="https://cdn.jsdelivr.net/npm/christmas-snow-3d/build/snow3d.js"></script>


document.head.appendChild((function() {
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = 'https://cdn.jsdelivr.net/npm/christmas-snow-3d/build/snow3d.js';
    return s;
})());

```
